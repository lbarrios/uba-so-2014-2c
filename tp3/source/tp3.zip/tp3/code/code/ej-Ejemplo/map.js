function() {
    emit(this.title,this.total_votes);
}