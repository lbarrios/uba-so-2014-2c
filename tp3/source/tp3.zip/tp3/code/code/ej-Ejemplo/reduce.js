function (key, values){
    return Array.sum(values);
}
  